![Java Number类](https://picgo-w.oss-cn-chengdu.aliyuncs.com/img/OOP_WrapperClass.png)

![img](https://picgo-w.oss-cn-chengdu.aliyuncs.com/img/2243690-9cd9c896e0d512ed.gif)



HHHHHH



![img](https://picgo-w.oss-cn-chengdu.aliyuncs.com/img/oopxxx.png)

1.22下午